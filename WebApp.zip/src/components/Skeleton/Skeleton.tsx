import React from 'react';
import './skeleton.css';

const Skeleton = () => {
  return <div className="skeleton"></div>;
};

export default Skeleton;
